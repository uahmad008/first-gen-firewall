/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication31;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jpcap.JpcapCaptor;
import jpcap.JpcapWriter;
import jpcap.packet.Packet;

/**
 *
 * @author Asim
 */
public class CheckClass {

    JpcapCaptor captor;
    jpcap.NetworkInterface[] devices = JpcapCaptor.getDeviceList();

//for each network interface
    void getInterfaces() {
        for (int i = 0; i < devices.length; i++) {
            //print out its name and description
            System.out.println(i + ": " + devices[i].name + "(" + devices[i].description + ")");

            //print out its datalink name and description
            System.out.println(" datalink: " + devices[i].datalink_name + "(" + devices[i].datalink_description + ")");

            //print out its MAC address
            System.out.print(" MAC address:");
            for (byte b : devices[i].mac_address) {
                System.out.print(Integer.toHexString(b & 0xff) + ":");
            }
            System.out.println();

        }
    }

    void openNetworkDevice(int num) throws IOException {
        captor = JpcapCaptor.openDevice(devices[num], 65535, false, 20);
        System.out.println("Device Opened!");
    }

    void startCapturing() throws IOException {
//        captor.processPacket(10, new PacketPrin0ter());
//
//        captor.close();
        JpcapWriter writer = JpcapWriter.openDumpFile(captor, "Captured Packets");

        // TODO add your handling code here:
        Packet packet = null;
        for (int j = 0; j < 10; j++) {
            //capture a single packet
            packet = captor.getPacket();
            //capture a single packet and print it out
            System.out.println(packet);
            //save it into the opened file
            writer.writePacket(packet);
        }

//        
        writer.close();
        captor.close();
        JOptionPane.showMessageDialog(null, "File saved!");
    }

// captor.processPacket(10,new PacketPrinter());
//
//                captor.close();
}
