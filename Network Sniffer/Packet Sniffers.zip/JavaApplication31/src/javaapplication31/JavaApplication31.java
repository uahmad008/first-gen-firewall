/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication31;

import java.io.IOException;
import java.net.SocketException;
import java.util.Scanner;
import jpcap.JpcapCaptor;

/**
 *
 * @author Asim
 */
public class JavaApplication31 {

    /**
     * @param args the command line arguments
     * @throws java.net.SocketException
     */
    JpcapCaptor captor;
        public static void main(String args[]) throws SocketException, IOException {
           CheckClass cc=new CheckClass();
           cc.getInterfaces();
           System.out.println("Choose index number: ");
           Scanner s=new Scanner(System.in);
           int num=s.nextInt();
           cc.openNetworkDevice(num);
           System.out.println("Start? (1/0)");
             s=new Scanner(System.in);
           int num1=s.nextInt();
           if(num1==1)
           {
               cc.startCapturing();
              
           }
           
    }

    }
    



