/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication31;

import jpcap.PacketReceiver;
import jpcap.packet.Packet;

/**
 *
 * @author Asim
 */
class PacketPrinter implements PacketReceiver {
  //this method is called every time Jpcap captures a packet
  @Override
  public void receivePacket(Packet packet) {
    //just print out a captured packet
    System.out.println(packet);
  }
}
